# NIVEA Generator - Vercel Deploy

1. Push this folder to GitHub
2. Go to vercel.com/new
3. Import repo
4. Deploy

No env vars needed.