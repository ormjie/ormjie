
"use client";
import { useState, useEffect, useMemo } from "react";
import "./globals.css";

const EN = [
"her glow just launched a revolution","NIVEA chose THE face NIVEA chose Lingling","First ever Thiamidol Body Serum and Lingling is the moment","That skin That glow Thats Lingling x NIVEA","Super glow era officially starts today","Lingling not just glowing she IS the glow","28 OCT 5PM BKK TIME we witness history","NIVEA THIAMIDOL WITH LINGLING is the headline we needed","Body serum but make it iconic","From face card to body glow Lingling owns it","Glow that launched a thousand carts","Linglings skin in HD we are blessed","This collab was written in the stars","NIVEA Super Glow unlocked with Lingling","No filter just Lingling glow","CEO of glow reporting for duty","Linglingkwong effect is real","Skin so bright it needs its own spotlight","The serum is super Lingling is super super","We asked for glow NIVEA gave us Lingling","Officially in our super glow era","Lingling serving body goals and glow goals","Thiamidol meets its perfect muse","Every angle is glow angle","NIVEA understood the assignment","Linglings glow is not a filter its a lifestyle","History made Thiamidol Body Serum has arrived","Super glow loading 100 percent Lingling","The glow we have been waiting for","Lingling made NIVEA even more iconic","Body care just got a main character","Lingling glow appreciation post","This is what super glow looks like","NIVEA x Lingling the duo we manifested","She is glowing we are screaming","Linglingkwong the human highlighter","Thiamidol Body Serum looks good on her already","Soft skin super glow Lingling approved","NIVEA THIAMIDOL WITH LINGLING say it louder","Lingling aura plus NIVEA glow equals unstoppable","Glow check passed by Lingling","Lingling is the blueprint for glow","Super glow is not a dream its Lingling","NIVEA found its glow queen","Linglings skin card never declines","We are seated for this launch event","Super glow season is Lingling season","Lingling glow is the new standard","Body serum era and Lingling leads it","That NIVEA glow hits different with Lingling","Lingling shining brighter than my future","First Thiamidol Body Serum ever and its Lingling","Glow so good it should be illegal","Linglingkwong for NIVEA we won","Super glow activated thanks to Lingling","Linglings glow has its own fanclub","NIVEA super glow plus Lingling super star","This collaboration ate no crumbs","Lingling glow is the trend","Skin goals sponsored by Lingling x NIVEA","Lingling making history in soft glow","Thiamidol Body Serum launch will be legendary","Linglings glow deserves a museum","Super glow queen has entered","NIVEA THIAMIDOL WITH LINGLING we are obsessed","Lingling glow on repeat","The face the body the glow all Lingling","Super glow but make it Linglingkwong","Lingling serving glowing skin realness","NIVEA glow looks best on Lingling","Lingling glow is my Roman Empire","This glow is certified Lingling approved","Super glow alert Lingling is here","Lingling glow supremacy","NIVEA x Lingling is mother","Thiamidol body serum launch of the year","Linglings glow is healing me","Super glow unlocked level Lingling","Lingling glow is the moment and the movement","NIVEA chose right NIVEA chose Lingling","Body glow so good thanks to Lingling","Lingling is glowing we are glowing","Super glow era initiated by Lingling","Linglings skin is literally super glow","NIVEA THIAMIDOL WITH LINGLING iconic duo","Glow like Lingling with NIVEA","Linglingkwong glow hits hard","Thiamidol meets glow meets Lingling","Lingling glow is not playing","Super glow looks expensive because it is Lingling","NIVEA super glow journey starts with Lingling","Linglings glow is my personality now","This launch is personal its Lingling","Super glow power by Lingling","Lingling glow for the win","NIVEA body serum just got iconic with Lingling","Linglings glow is the blueprint","Super glow is Linglings signature","Lingling glow takeover is real","Thiamidol Body Serum has its queen","Lingling glow is extra bright today","NIVEA x Lingling is a cultural reset","Glow so soft glow so Lingling","Linglingkwong super glow era is here","Super glow loading with Lingling as host","Linglings skin is the ad we needed","NIVEA THIAMIDOL WITH LINGLING forever iconic","Lingling glow appreciation hour","Thiamidol body glow ft Lingling perfection","Lingling glow is top tier","Super glow confirmed by Lingling","Lingling glow is the main event","NIVEA super glow looks like Lingling","Glow goals achieved Lingling edition","Lingling glow is unmatched","Super glow queen Lingling is here","NIVEA launch event will glow with Lingling","Linglings glow is pure serotonin","Thiamidol serum plus Lingling equals perfection","Super glow is Linglings middle name","Lingling glow is the standard now","NIVEA THIAMIDOL WITH LINGLING we are ready","Lingling glow is literally glowing","Super glow era powered by Linglingkwong","Lingling glow never misses","Thiamidol body serum debut with queen Lingling","Lingling glow is my favorite filter","Super glow looks like Lingling","NIVEA x Lingling glow story begins","Linglings glow is iconic behavior","Glow so good its Lingling","Super glow mission accomplished by Lingling","Lingling glow is trending and we see why","NIVEA THIAMIDOL WITH LINGLING super moment","Lingling glow is the vibe","Thiamidol body serum first ever with Lingling","Lingling glow is divine","Super glow served by Lingling","Linglingkwong glow domination","NIVEA super glow era starts with Lingling","Linglings glow is a love language","Glow check Lingling verified","Super glow unlocked Lingling mode on","Lingling glow is the headline","Thiamidol body serum meets its icon","Linglings glow is art","NIVEA x Lingling glow supremacy","Super glow looks better on Lingling","Lingling glow is everything","Lingling glow hour is every hour","Thiamidol body serum glow by Lingling","Super glow energy Lingling edition","Lingling glow is my aesthetic","NIVEA THIAMIDOL WITH LINGLING period","Lingling glow is the moment","Glow with Lingling glow with NIVEA","Super glow queen Linglingkwong","Thiamidol body serum has a face Lingling","Linglings glow is legendary","NIVEA super glow ft Lingling forever","Lingling glow is super super","Glow so Lingling coded","Super glow era Lingling version","Lingling glow is main character energy","Thiamidol body serum launch we waited for","Linglings glow is unreal","NIVEA x Lingling glow goals unlocked","Super glow is here and its Lingling","Lingling glow obsession is real","Glow like never before with Lingling","Thiamidol body serum iconic debut","Lingling glow takeover complete","NIVEA THIAMIDOL WITH LINGLING iconic link up","Super glow looks like this Lingling","Lingling glow is the blueprint again","Glow with confidence glow with Lingling","Thiamidol body serum super glow starts","Lingling glow appreciation never ends","NIVEA super glow is Lingling glow","Lingling glow is pure magic","Super glow era officially Lingling","Lingling glow is my favorite view","Thiamidol body serum glow with queen","Linglings glow is next level","NIVEA x Lingling is glow destiny","Super glow served fresh by Lingling","Lingling glow is the moment we needed","Glow up brought to you by Lingling x NIVEA","Thiamidol body serum first with Lingling","Lingling glow supremacy continues","NIVEA THIAMIDOL WITH LINGLING shine on","Super glow check Lingling passed","Lingling glow is timeless","Thiamidol body serum glow era begins","Linglings glow is my inspiration","NIVEA glow era is Lingling era","Super glow icon Linglingkwong","Lingling glow is the trendsetter","Glow with Lingling glow forever","Thiamidol body serum meets Lingling magic","Lingling glow is elite","NIVEA x Lingling super glow forever","Super glow moment is Lingling moment","Lingling glow is the one","Glow so soft thanks to Lingling","Thiamidol body serum launch Lingling glow","Lingling glow is the future","NIVEA THIAMIDOL WITH LINGLING glow up","Super glow queen is Lingling","Lingling glow never fails","Thiamidol body serum iconic with Lingling","Linglings glow is super power","NIVEA super glow defined by Lingling","Lingling glow is my happy place","Super glow is Lingling language","Glow like Lingling today","Thiamidol body serum x Lingling forever","Lingling glow is iconic and we love it","NIVEA x Lingling glow takeover","Super glow is Lingling approved","Lingling glow is the real deal","Glow season is Lingling season","Thiamidol body serum debut glow with Lingling","Lingling glow is our obsession","NIVEA THIAMIDOL WITH LINGLING super glow icons","Super glow vibes only with Lingling","Lingling glow is heavenly","Thiamidol body serum glow with Linglingkwong","Linglings glow is super iconic","NIVEA super glow journey Lingling leads","Lingling glow is what we live for","Super glow era Lingling unlocked","Glow with Lingling every day","Thiamidol body serum has arrived with Lingling","Lingling glow is the ultimate","NIVEA x Lingling glow magic","Super glow looks like Lingling glow","Lingling glow is certified super","Glow goals Lingling edition complete","Thiamidol body serum super glow moment","Lingling glow is main event always","NIVEA THIAMIDOL WITH LINGLING glow queen","Super glow is Lingling glow","Lingling glow domination era","Thiamidol body serum launch with icon Lingling","Linglings glow is everything we need","NIVEA super glow Lingling super glow","Lingling glow is forever iconic","Super glow is Lingling energy","Glow with NIVEA glow with Linglingkwong","Thiamidol body serum first ever iconic","Lingling glow is the one and only","NIVEA THIAMIDOL WITH LINGLING super glow history","Super glow alert its Lingling","Lingling glow is our favorite aesthetic","Thiamidol body serum glow icon Lingling","Linglings glow is unmatched and forever","NIVEA x Lingling glow up complete","Super glow moment starring Lingling","Lingling glow is what dreams are made of","Glow so bright its Lingling","Thiamidol body serum launch glow queen Lingling","Lingling glow is trending for a reason","NIVEA THIAMIDOL WITH LINGLING super glow love","Super glow era is now with Lingling","Lingling glow is divine glow","Thiamidol body serum with Lingling is fate","Linglings glow is our mood","NIVEA super glow ft Linglingkwong iconic","Lingling glow is pure perfection","Super glow by Lingling for NIVEA","Glow with Lingling shine with NIVEA","Thiamidol body serum queen Lingling era","Lingling glow is super glow goals","NIVEA x Lingling glow takeover starts","Super glow icon is Lingling","Lingling glow is the ultimate glow","Glow check super glow by Lingling","Thiamidol body serum launch iconic Lingling","Linglings glow is forever glow","NIVEA THIAMIDOL WITH LINGLING glow legend","Super glow served by queen Lingling","Lingling glow is the best glow","Body serum but make it Lingling iconic","Lingling is super glow personified","NIVEA glow era is Lingling glow era"
];

const TH = EN.map((en,i)=>{
  const base = ["ความโกลว์ของหลิงเปิดตัวแบบปฏิวัติ","NIVEA เลือกถูกคนแล้ว เลือกหลิง","ครั้งแรกของ Thiamidol Body Serum ต้องเป็นหลิง","ผิวนี้โกลว์นี้ ต้องหลิง x NIVEA","ยุคซุปเปอร์โกลว์เริ่มวันนี้","หลิงไม่ได้แค่โกลว์ แต่หลิงคือโกลว์","28 ตุลา 5โมงเย็น เราจะเป็นสักขีพยาน","พาดหัวที่รอคอย NIVEA THIAMIDOL WITH LINGLING","บอดี้เซรั่มแต่ไอคอนิก","ตั้งแต่หน้าไปถึงตัว หลิงเอาอยู่"];
  return base[i % base.length] + " #หลิงหลิงคอง";
});

export default function Page(){
  const [copied,setCopied]=useState<Set<number>>(new Set());
  const [search,setSearch]=useState("");
  const [hideCopied,setHideCopied]=useState(false);
  const [thaiOn,setThaiOn]=useState(false);
  const [copyMode,setCopyMode]=useState<"en"|"th"|"both">("en");
  const [current,setCurrent]=useState(0);
  const [toast,setToast]=useState("");

  useEffect(()=>{
    const s=localStorage.getItem("nivea-copied");
    if(s) setCopied(new Set(JSON.parse(s)));
  },[]);
  useEffect(()=>{localStorage.setItem("nivea-copied",JSON.stringify([...copied]))},[copied]);

  const makeText=(idx:number)=>{
    let body="";
    if(copyMode==="en") body=EN[idx];
    if(copyMode==="th") body=TH[idx];
    if(copyMode==="both") body=EN[idx]+"\n"+TH[idx];
    return body+"\n\nNIVEA THIAMIDOL WITH LINGLING\n#NIVEASuperGlowXLingling";
  };
  const doCopy=(idx:number)=>{
    navigator.clipboard.writeText(makeText(idx));
    setCopied(prev=>new Set([...prev,idx]));
    setToast("Copied #"+(idx+1));
    setTimeout(()=>setToast(""),2000);
  };
  const filtered=useMemo(()=>EN.map((en,i)=>({en,th:TH[i],i})).filter(o=>{
    if(hideCopied && copied.has(o.i)) return false;
    if(search && !o.en.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  }),[search,hideCopied,copied]);

  const randomize=()=>{
    const avail=EN.map((_,i)=>i).filter(i=>!copied.has(i));
    const pool=avail.length?avail:EN.map((_,i)=>i);
    setCurrent(pool[Math.floor(Math.random()*pool.length)]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-pink-50 to-purple-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <header className="bg-white/80 backdrop-blur rounded-3xl p-6 shadow-xl border mb-6">
          <h1 className="text-3xl md:text-5xl font-black text-blue-900">NIVEA THIAMIDOL WITH LINGLING</h1>
          <p className="mt-2 text-blue-800/70">#NIVEASuperGlowXLingling | 28 OCT 2026 5PM BKK | {copied.size}/300 Used | Vercel Ready</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search..." className="px-4 py-2 rounded-xl border bg-white" />
            <button onClick={randomize} className="bg-blue-900 text-white px-5 py-2 rounded-xl font-bold">Randomize</button>
            <button onClick={()=>{setCopied(new Set()); localStorage.removeItem("nivea-copied")}} className="border bg-white px-4 py-2 rounded-xl">Unlock All</button>
            <label className="flex items-center gap-2 bg-white border px-3 py-2 rounded-xl text-sm"><input type="checkbox" checked={thaiOn} onChange={e=>setThaiOn(e.target.checked)} /> TH Toggle</label>
            <label className="flex items-center gap-2 bg-white border px-3 py-2 rounded-xl text-sm"><input type="checkbox" checked={hideCopied} onChange={e=>setHideCopied(e.target.checked)} /> Hide Copied</label>
            <select value={copyMode} onChange={e=>setCopyMode(e.target.value as any)} className="border rounded-xl px-3 py-2 bg-white text-sm"><option value="en">EN Only</option><option value="th">TH Only</option><option value="both">EN+TH</option></select>
          </div>
        </header>

        <div className="bg-white rounded-3xl p-6 shadow-xl border mb-6">
          <div className="flex justify-between mb-4">
            <b>Current #{current+1} {copied.has(current) && <span className="text-green-600">COPIED</span>}</b>
            <div className="flex gap-2">
              <button onClick={()=>doCopy(current)} className="bg-blue-900 text-white px-6 py-2 rounded-full font-bold">Copy</button>
              <button onClick={()=>setCurrent((current+1)%300)} className="border px-4 py-2 rounded-full">Next</button>
            </div>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-pink-50 rounded-2xl p-6 whitespace-pre-wrap">
            {copyMode==="en" && EN[current]}
            {copyMode==="th" && TH[current]}
            {copyMode==="both" && <><div>{EN[current]}</div><div className="mt-2 text-purple-700">{TH[current]}</div></>}
            {thaiOn && copyMode==="en" && <div className="mt-3 pt-3 border-t text-sm opacity-70">{TH[current]}</div>}
            <div className="mt-4 pt-4 border-t"><br/>NIVEA THIAMIDOL WITH LINGLING<br/>#NIVEASuperGlowXLingling</div>
          </div>
          <a className="inline-block mt-3 text-blue-900 underline text-sm" href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(makeText(current))}`} target="_blank">Post to X</a>
        </div>

        <div className="grid md:grid-cols-2 gap-3">
          {filtered.map(({en,th,i})=>(
            <div key={i} className={`bg-white rounded-2xl p-4 border shadow-sm ${copied.has(i)?"opacity-50":""}`}>
              <div className="flex justify-between"><span className="text-xs text-gray-400">#{i+1} {copied.has(i)?"COPIED":""}</span><button onClick={()=>doCopy(i)} disabled={copied.has(i)} className={`text-xs px-3 py-1 rounded-full ${copied.has(i)?"bg-gray-200":"bg-blue-900 text-white"}`}>{copied.has(i)?"Locked":"Copy"}</button></div>
              <div className="mt-2 whitespace-pre-wrap text-sm">{en}{thaiOn && <div className="text-xs opacity-60 mt-1">{th}</div>}<div className="mt-2"><br/>NIVEA THIAMIDOL WITH LINGLING<br/>#NIVEASuperGlowXLingling</div></div>
            </div>
          ))}
        </div>

        {toast && <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-black text-white px-6 py-3 rounded-full">{toast}</div>}
      </div>
    </div>
  )
}
