export const metadata = { title: 'NIVEA THIAMIDOL WITH LINGLING Generator', description: '300 trending captions' }
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body>{children}</body></html>)
}
